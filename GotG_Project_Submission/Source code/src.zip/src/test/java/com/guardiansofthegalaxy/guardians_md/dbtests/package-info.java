/**
 * Package: com.guardiansofthegalaxy.guardians_md.dbtests
 * 		This package is the main JUnit testing package for the project.
 * It runs tests on classes in the com.guardiansofthegalaxy.guardians_md.db
 * package.
 **/
package com.guardiansofthegalaxy.guardians_md.dbtests;